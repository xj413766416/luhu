<?php

defined('BASEPATH') or exit('No direct script access allowed');
include_once 'Base.php';

class Article extends Base
{

    /**
     * 初始化
     */
    public function __construct()
    {
        parent::__construct();
        $this->userDiary           = new \Xy\Application\Models\UserDiaryModel();
        $this->option              = new \Xy\Application\Models\UserOptionModel();
    }

    public function index(){
        $info = $this->input->request(null, true);
        $id = $info['id'];
        $data = $this->userDiary->getDiaryInfoById($id);
        $num = $data['num'];
        if($num == 2) {
            $view = 'people';
        } elseif($num == 3) {
            $view = 'animal';
        }elseif($num == 4) {
            $view = 'food';
        }elseif($num == 5) {
            $view = 'view';
        } else {
            $view = 'initial';
        }

        $pink = $this->option->getUserOption($this->_data['openId'], $id);
        $data['pink'] = $pink ? 1 : 2;

        $data['view'] = $view;
        $data['content'] = json_decode($data['content'],true);

        $res = $this->Users->getUserInfoByUid($data['uid']);
        $data['avatar'] = $res['avatar'];
        $this->displayMain($data);
    }
}

