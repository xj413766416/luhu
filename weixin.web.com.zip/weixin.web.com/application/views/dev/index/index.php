<div class="wrapper">
    <div class="layout bg-index">
        <div class="logo flex center">
            <i><img src="<?= STATIC_ASSETS ?>images/logo1.png" alt=""></i>
            <i><img src="<?= STATIC_ASSETS ?>images/logo2.png" alt=""></i>
        </div>
        <div class="link-box auto">
            <div class="link-list">
                <a href="<?php echo site_url('User', 'activity', ['type' => 1]); ?>">
                    <div class="btn flex center jc">我是体验官<i><img src="<?= STATIC_ASSETS ?>images/icon-1.png" alt=""></i></div>
                </a>
                <div class="ta-c msg">我已经付款确认参与线路游</div>
            </div>
            <div class="link-list">
                <a href="<?php echo site_url('User', 'index', ['type' => 2]); ?>">
                    <div class="btn flex center jc">开启探索<i><img src="<?= STATIC_ASSETS ?>images/icon-1.png" alt=""></i></div>
                </a>
                <div class="ta-c msg">我已了解路虎/松赞产品</div>
            </div>
            <div class="link-list">
                <a href="<?php echo site_url('User', 'index', ['type' => 3]); ?>">
                    <div class="btn flex center jc">全新探索<i><img src="<?= STATIC_ASSETS ?>images/icon-1.png" alt=""></i></div>
                </a>
                <div class="ta-c msg">我尚未了解路虎/松赞产品</div>
            </div>
        </div>
    </div>
</div>
