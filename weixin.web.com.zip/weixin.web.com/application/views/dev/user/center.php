<div class="wrapper">
    <div class="layout bg-self">
        <div class="logo flex center">
            <i><img src="<?= STATIC_ASSETS ?>images/logo1.png" alt=""></i>
            <i><img src="<?= STATIC_ASSETS ?>images/logo2.png" alt=""></i>
        </div>
        <div class="header flex end justify">
            <div class="left">
                <div class="header-pic auto"><img src="<?= $avatar; ?>" alt=""></div>
                <div class="name ta-c"><?= $nickname; ?></div>
            </div>
            <div class="code">个人推荐码：<span><?= $code; ?></span></div>
        </div>
        <div class="content myselfinfo-cont">
            <ul>
                <li><a href="<?php echo site_url('Diary', 'index'); ?>"><img src="<?= STATIC_ASSETS ?>images/note-1.png" alt=""></a></li>
                <li><a href="<?php echo site_url('User', 'travel', ['type' => $type]); ?>"><img src="<?= STATIC_ASSETS ?>images/note-2.png" alt=""></a></li>
                <li><a href="<?php echo site_url('User', 'activity', ['type' => 3]); ?>"><img src="<?= STATIC_ASSETS ?>images/note-3.png" alt=""></a></li>
                <li><a href="<?php echo site_url('User', 'feedback'); ?>"><img src="<?= STATIC_ASSETS ?>images/note-4.png" alt=""></a></li>
            </ul>
        </div>
        <div class="find-end">
            <div class="tit">
                革命性设计，巧妙多功能性，<br/>
                以及与生俱来的路虎全地形能力
            </div>
            <div class="link">
                <a href="https://www.landrover.com.cn/vehicles/discovery/index.html">了解路虎新款发现</a>
            </div>
            <div class="link">
                <a href="http://www.songtsam.com/">了解松赞文旅</a>
            </div>
        </div>
    </div>
</div>