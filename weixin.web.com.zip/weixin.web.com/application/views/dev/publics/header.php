<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta name="format-detection" content="telephone=no, email=no"/>
    <meta name="msapplication-tap-highlight" content="no">
    <title></title>
    <link href="<?= STATIC_ASSETS ?>css/base.css" rel="stylesheet" type="text/css">
    <script src="<?= STATIC_ASSETS ?>js/jquery.min.js" type="text/javascript"></script>
    <script src="<?= STATIC_ASSETS ?>js/main.js" type="text/javascript"></script>
</head>
<html>
<body>