<?php
/**
 * Created by PhpStorm.
 * User: xujian
 * Date: 2016/10/20
 * Time: 15:00
 */
namespace Xy\Application\Models\Redis;

class MjChannelRedis extends BaseRedis
{
    /**
     * 初始化
     */
    public function __construct()
    {
        parent::__construct();
    }
}
