<?php
/**
 * Created by PhpStorm.
 * User: xujian
 * Date: 2016/10/10
 * Time: 15:43
 */
namespace Xy\Application\Models\Redis;

class RecommendClassRedis extends BaseRedis
{
    /**
     * 初始化
     */
    public function __construct()
    {
        parent::__construct();
    }
}
