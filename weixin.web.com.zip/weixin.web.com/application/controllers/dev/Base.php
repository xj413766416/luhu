<?php
defined('BASEPATH') or exit('No direct script access allowed');

include_once APPPATH . 'controllers/Common.php';
class Base extends Common
{
    const DEFAULT_PAGE_LIST     = 5;//默认分页
    const MD5_STR_PREFIX        = 'xyzs@l#s￥m%&!*';//md5 加密前缀字符串
    const VALIDATE_CODE         = false;
    const SMS_LOGIN             = 3;//false 不需要 1 pc 2 mobile 3 全部

    public $user_info           = array();//登录用户信息 session


    /**
     * 无权限判断访问的地址设置
     *
     * @var array
     */
    private $free_url = array(

    );

    /**
     * 初始化
     */
    public function __construct()
    {
        parent::__construct();
        #载入后台权限操作相关(管理员 菜单 角色)
        $this->Users           = new \Xy\Application\Models\UserModel();
       // set_cookie('openId', 'od_fn1ZW3f-rjlrlETndbTzbxsZI');exit;
        //配置模板路径
        $this->_more_view_path = PROJECT_NAME;
        $controller = ucfirst($this->router->fetch_class());

        if($controller != 'Publics' && $controller != 'Article') {
            //$res = $this->isLogin();
        }
        $this->_data['openId'] = get_cookie('openId');
        if($controller == 'Index') {
            if($res['status'] == '2') {
                redirect(site_url('User', 'center'));
            }
        }

    }

    /**
     * 判断是否在无权限访问
     */
    public function isLogin()
    {
        $openid = get_cookie('openId');
        $res = $this->Users->getUserInfoByOpId($openid);
        if(!$openid || !$res ) {
            $this->get_openid();
        }
        return $res;
    }

    /**
     * 获取登录用户信息
     *
     * @return bool
     */
    protected function getUserInfoByLogin()
    {
        $session_info = $this->session->get_userdata();

        $ret = array();

        if ($session_info['id']) {
            $ret = $this->DevUser->AdminUsers(array("id" => $session_info['id']));
        }

        return $ret ? ($ret + $session_info + array('is_login' => 1)) : array('is_login' => 0);
    }


    /**
     * 操作跳转提示方法
     *
     * @param null $url
     * @param null $message
     * @param null $app_id
     */
    protected function redirectTips($url = null, $message = null, $app_id = null)
    {
        redirect(site_url('Publics', 'tips', array('url' => $url, 'message' => $message, 'app_id' => $app_id)));
    }

    /**
     * 渲染 main 模板
     *
     * @param array $data
     * @param null $view
     */
    public function displayMain($data = array(), $view = null)
    {
        if ($view == null) {
            $view = $this->_more_view_path . '/' . strtolower($this->router->fetch_class()) . '/' . $this->router->fetch_method();
        } else {
            $view = $this->_more_view_path . '/' . $view;
        }


        $data = array_merge($this->_data, $data);

        $data['main_html'] = $this->load->view($view, $data, true);

        $this->load->view($this->_more_view_path . '/' . 'publics/main', $data);

        //统计页面访问量
        $url_info = $this->_data;
        if(strtolower($this->router->fetch_class()) == 'article') {
            $this->view_play($this->_data['openId'], $data['id']);
        }
        $url = '/'.PROJECT_NAME.'/'.$url_info['controller'].'/'.$url_info['method'];
        $this->view_assess($url);
        //调试页面执行时间用
        if (IS_DEBUG) {
            echo 'page_run_time:</br>';
            var_dump(code_run_time());
        }
    }

    /**
     * 密码md5加密后截取
     *
     * @param $pwd
     * @return string
     */
    public function pwdMd5($pwd)
    {
        return substr(md5($pwd.self::MD5_STR_PREFIX), 0, 10);
    }


    /**
     * 登录发送验证码
     */
    public function phoneSmsSendByLogin()
    {
        if (IS_GET) {
            $iphone      = $this->input->get('iphone', true);
            $sms_str = rand_str(6);
            $sms_notice_obj = new SendSms();
            $sms_ret = $sms_notice_obj->send($iphone, $sms_str);
            if ($sms_ret['code'] == 200) {
                set_cookie('code', $sms_str);
                $this->AjaxReturn(self::AJ_RET_SUCC, '获取短信成功,5分钟内有效#');
            } else {
                $this->AjaxReturn(self::AJ_RET_FAIL, $sms_ret['msg']);
            }
        } else {
            $this->AjaxReturn(self::AJ_RET_FAIL, '请求失败~');
        }
    }

    /**
     * 手机短信验证
     *
     * @param $tel
     * @param bool $check_code
     * @return bool
     */
    public function phoneSmsCheck($tel, $check_code = false)
    {
        if (in_array(self::SMS_LOGIN, array(1, 2, 3))) {
            if (verify_phone($tel)) {
                if ($check_code) {
                    $sms_str = $this->input->get_post('sms_code', true);
                    //比对mem缓存 验证码
                    $real_sms_str = $this->AdminUsers->getUserPhoneCode($tel);

                    if ($sms_str == $real_sms_str && !empty($sms_str)) {
                        return true;
                    } else {
                        return false;//短信验证码错误
                    }
                } else {
                    return true;
                }
            } else {
                return false;//手机号码格式错误，请联系管理员处理
            }
        } else {
            return true;
        }
    }

    /**
     * ajax返回格式
     *
     * @param int $code
     * @param null $msg
     * @param null $rel
     * @param null $data
     */
    public function AjaxReturn($code = self::AJ_RET_SUCC, $msg = null, $rel = null, $data = null)
    {
        $arr["code"]       = $code;
        $arr["msg"]        = $msg;
        $arr["forward"]    = $rel;
        $arr["data"]       = $data;
        echo json_encode($arr);
        exit;
    }



    /**
     *  获取用户openid，保存名片用
     * @param string $url
     */
    public function get_openid($url = '')
    {
        $state = '1111';
        $appid = APPID;
        if(empty($url)) {
            $url = REDIRECT_URL;
        }
        $redirect_uri = urlencode($url);
        //对url处理，此url为访问上面jump方法的url
        $url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=$appid&redirect_uri=$redirect_uri&response_type=code&scope=snsapi_base&state=$state#wechat_redirect";
        header('Location:' . $url);
    }
}
